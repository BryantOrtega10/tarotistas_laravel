<?php

namespace App\Http\Requests\Api\Request\Cliente;

use App\Http\Requests\Api\ApiRequest;


class CalificarLlamadaRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'calificacion' => 'required',
            'comentario' => 'nullable',
        ];
    }
}
